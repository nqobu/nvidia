# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import os
import numpy as np
import json
from multiprocessing import Pool, cpu_count
from functools import partial
import polars as pl

from src.tokenizer import Tokenizer
from tqdm import tqdm


def tokenize_sequence(args):
    cds_sequence, tokenizer = args
    return "".join(map(chr, tokenizer.convert_tokens_to_ids(tokenizer.tokenize(cds_sequence))))

def preload_csv_files(data_path, tokenizer, save_path, chunk_size, num_workers=cpu_count(), min_cds_len=100, max_cds_len=1.5e5):
    chunks_metadata_path = os.path.join(save_path, "chunks_metadata.json")

    chunks_metadata = []
    processed_metadata = [] 
    current_chunk_tokens = 0
    chunk_counter = 0
    completed_chunk_ids = set()
    
    data_dict = {}
    processed_data_path = os.path.join(save_path, "data_processed")
    os.makedirs(processed_data_path, exist_ok=True)
    
    for file_name in sorted(os.listdir(data_path)):
        if file_name.endswith(".csv"):
            file_path = os.path.join(data_path, file_name)
            cached_file_path = os.path.join(processed_data_path, f"{file_name}.parquet")
            if os.path.exists(cached_file_path):
                print(f"Loading cached data for {file_name}...")
                df = pl.read_parquet(cached_file_path, columns=['cds_tokens','taxid', 'cds_tokens_length'] )
                print('loaded', df.shape[0])
            else:
                print(f"Processing and tokenizing {file_name}...")
                df = pl.read_csv(file_path)
                with Pool(cpu_count()) as pool:
                    bs = 1000000
                    tokenized_sequences = []
                    for bi in range(0,df.shape[0],bs):
                        cds_sequences = df[bi:bi+bs,"cds"].to_list()
                        tokenized_sequences += list(
                            tqdm(
                                pool.imap(
                                    tokenize_sequence,
                                    [(seq, tokenizer) for seq in cds_sequences]
                                ),
                                total=len(cds_sequences),
                                desc=f"Tokenizing {file_name}",
                            )
                        )

                df = df.with_columns(pl.Series("cds_tokens", tokenized_sequences))
                df = df.with_columns(
                    pl.col("cds_tokens").str.len_chars().alias("cds_tokens_length")
                )
                df.write_parquet(cached_file_path)
                print("Saved")
            df = df.with_columns(
                pl.col("cds_tokens").map_elements(lambda x: np.frombuffer(x.encode('utf-8'), dtype=np.uint8), return_dtype=pl.Object).alias("cds_tokens_encoded")
            )
            sequences_flat = df["cds_tokens_encoded"].to_list()
            taxid_series = df["taxid"].to_numpy()
            token_lengths = df["cds_tokens_length"].to_numpy()
            del df
            sequences_flat = np.concatenate(sequences_flat).astype(np.uint8)
            remaining_chunks_metadata = []
            print("Computing new chunks metadata...")

            start_idx = 0
            
            for idx, seq_len in enumerate(tqdm(token_lengths)):
                if chunk_size and current_chunk_tokens + seq_len > chunk_size and current_chunk_tokens > 0:
                    remaining_chunks_metadata.append([chunk_counter,(file_path, start_idx, idx - 1)])
                    chunk_counter += 1

                    start_idx = idx
                    current_chunk_tokens = 0
                current_chunk_tokens += seq_len
    
            if start_idx <= len(token_lengths) - 1:
                remaining_chunks_metadata.append([chunk_counter, (file_path, start_idx, len(token_lengths) - 1)])
                chunk_counter += 1
                current_chunk_tokens = 0
            chunks_metadata += remaining_chunks_metadata
            
            if num_workers == 0:
                for chunk_id, (file_path, start_row_idx, end_row_idx) in tqdm(remaining_chunks_metadata, total=len(remaining_chunks_metadata)):
                # for task_args in tqdm(tasks_args_list, total=len(tasks_args_list)):
                    result = save_chunk(chunk_id,
                        (file_path, start_row_idx, end_row_idx),
                        save_path,
                        token_lengths,
                        taxid_series,
                        sequences_flat)
                    processed_metadata.append(result)
                    completed_chunk_ids.add(chunk_id)
                    #update_completed_chunks(save_path, list(completed_chunk_ids))
            else:
                tasks_args_list = []
                for chunk_id, (file_path, start_row_idx, end_row_idx) in remaining_chunks_metadata:
                    tasks_args_list.append((
                        chunk_id,
                        (file_path, start_row_idx, end_row_idx),
                        save_path,
                        token_lengths,
                        taxid_series,
                        sequences_flat
                    ))
                with Pool(num_workers) as pool:
                    for idx, result in tqdm(
                        zip([task[0] for task in tasks_args_list], pool.starmap(save_chunk, tasks_args_list)),
                        total=len(tasks_args_list)
                    ):
                        completed_chunk_ids.add(idx)
                        #update_completed_chunks(save_path, list(completed_chunk_ids))
                        processed_metadata.append(result)

            with open(chunks_metadata_path, 'w') as f:
                json.dump(chunks_metadata, f)

    final_metadata = {
        "chunks": processed_metadata,
        "tokenizer": tokenizer.get_vocab(),
        "file_metadata": [{"file_name": os.path.basename(chunk[1][0]), "start": chunk[1][1], "end": chunk[1][2]} for chunk in chunks_metadata]
    }

    with open(os.path.join(args.save_path, "metadata.json"), 'w') as f:
        json.dump(final_metadata, f, indent=4)
    return 



def save_chunk(chunk_id, chunk_info, save_path, token_lengths, taxid_series, sequences_flat):
    sequence_mmap_path = os.path.join(save_path, f"sequences_chunk{chunk_id}.mmap")
    index_mmap_path = os.path.join(save_path, f"index_chunk{chunk_id}.mmap")

    _, start_row_idx, end_row_idx = chunk_info

    token_lengths_slice = token_lengths[start_row_idx:end_row_idx + 1]
    taxid_slice = taxid_series[start_row_idx:end_row_idx + 1]

    start_token_pos = np.sum(token_lengths[:start_row_idx])
    end_token_pos = start_token_pos + np.sum(token_lengths_slice)

    sequences_flat_slice = sequences_flat[start_token_pos:end_token_pos]

    end_idxs_global = np.cumsum(token_lengths_slice)
    start_idxs_global = np.concatenate(([0], end_idxs_global[:-1]))

    indices_array = np.column_stack((start_idxs_global, end_idxs_global, taxid_slice)).astype(np.uint32)

    sequence_mmap = np.memmap(sequence_mmap_path, dtype='uint8', mode='w+', shape=sequences_flat_slice.shape)
    index_mmap = np.memmap(index_mmap_path, dtype='uint32', mode='w+', shape=indices_array.shape)

    sequence_mmap[:] = sequences_flat_slice[:]
    index_mmap[:] = indices_array[:]

    sequence_mmap.flush()
    index_mmap.flush()

    return {
        "sequences": {"path": os.path.basename(sequence_mmap_path),"shape":sequence_mmap.shape,"dtype":"uint8"},
        "index": {"path": os.path.basename(index_mmap_path),"shape":index_mmap.shape,"dtype":"uint32"}
     }

def update_completed_chunks(save_path, completed_chunk_ids):
    completed_chunks_file = os.path.join(save_path, "completed_chunks.json")
    with open(completed_chunks_file, 'w') as f:
        json.dump(completed_chunk_ids, f)


def load_completed_chunks(save_path):
    completed_chunks_file = os.path.join(save_path, "completed_chunks.json")
    if os.path.exists(completed_chunks_file):
        with open(completed_chunks_file) as f:
            return set(json.load(f))
    return set()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Optimized Chunk-level parallel processing.")
    parser.add_argument("--data-path", required=True)
    parser.add_argument("--save-path", required=True)
    parser.add_argument("--chunk-size", type=int, default=1_000_000_000)
    parser.add_argument("--min-cds-len", type=int, default=100)
    parser.add_argument("--max-cds-len", type=float, default=1.5e5)
    parser.add_argument("--num-workers", type=int, default=cpu_count())

    args = parser.parse_args()

    tokenizer = Tokenizer(
        cls_token="<CLS>", bos_token="<CLS>", sep_token="<SEP>", unk_token="<UNK>",
        pad_token="<PAD>", mask_token="<MASK>", padding_side="right",
        truncation="right", seq_type="dna"
    )

    print("Preloading CSV files...")
    preloaded_data_tokenized = preload_csv_files(
        args.data_path,
        tokenizer,
        args.save_path,
        args.chunk_size,
        num_workers = args.num_workers,
        min_cds_len=args.min_cds_len,
        max_cds_len=args.max_cds_len
    )

    print(f"✅ Processing complete. Outputs saved to {args.save_path}")