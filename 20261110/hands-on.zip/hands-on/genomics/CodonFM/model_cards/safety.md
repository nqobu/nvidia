Field                                               |  Response
:---------------------------------------------------|:----------------------------------
Model Application Field(s):                               |  Genomics/Biotechnology
Describe the life critical impact (if present).   |  Not Applicable <br>
Use Case Restrictions:                              |  Abide by the [NVIDIA Open Model License Agreement](https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-open-model-license/).
Model and dataset restrictions:            |  The Principle of least privilege (PoLP) is applied limiting access for dataset generation and model development.  Restrictions enforce dataset access during training, and dataset license constraints adhered to.
