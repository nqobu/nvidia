# LULESH

```
# Download source code
git clone --branch 2.0.3 https://github.com/LLNL/LULESH.git

# Load software modules (GNU)
module purge
module load gcc/13.3.0-gcc-11.4.1
module load openmpi/5.0.6-gcc-13.3.0

cd LULESH

# Edit the Makefile
# You can also use the Makefile from this repository
vim Makefile
  8 MPI_INC = /global/exafs/groups/gh/sw-env-202412/opt/linux-rocky9-neoverse_v2/gcc-13.3.0/openmpi-5.0.6-t2hxjz4naya77lifblyakjc5croc3uam/include
  9 MPI_LIB = /global/exafs/groups/gh/sw-env-202412/opt/linux-rocky9-neoverse_v2/gcc-13.3.0/openmpi-5.0.6-t2hxjz4naya77lifblyakjc5croc3uam/lib
 12 MPICXX = mpicxx -DUSE_MPI=1 -DUSE_OMP=0
 24 CXXFLAGS = -g -O3 -I. -Wall
 25 LDFLAGS = -g -O3

make -j

# Run simple case
# More info:
#   * https://asc.llnl.gov/sites/asc/files/2023-05/LULESH2.0_Changes.pdf
export OMP_NUM_THREADS=1
mpirun -np 8 ./lulesh2.0 -s 16 -p
```
