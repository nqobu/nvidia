#!/bin/bash

#SBATCH --job-name=lulesh_gcc
#SBATCH --partition=gg
#SBATCH --ntasks=144
#SBATCH --cpus-per-task=1
#SBATCH --exclusive
#SBATCH --output=lulesh_gcc-%j.out

source /global/exafs/groups/gh/bootstrap-env-hipeac.sh
module purge
module load gcc/13.3.0-gcc-11.4.1
module load openmpi/5.0.6-gcc-13.3.0
module list

mpirun -np 8 ./lulesh2.0 -s 64 -i 10 -p
