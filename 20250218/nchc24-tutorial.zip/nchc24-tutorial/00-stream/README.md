# STREAM Benchmark

## Source code
Source code available [here](https://www.cs.virginia.edu/stream/FTP/Code/Versions/stream_mpi.c).

```
wget https://www.cs.virginia.edu/stream/FTP/Code/Versions/stream_mpi.c
```

## Input 
The problem size is given at compile time.
According to the benchmark rules, each array must me at least x3 the L3 cache size.

```
STREAM_ARRAY_SIZE=$(( 117*1*3*1000000/8 )) # Use this for 1 socket runs
STREAM_ARRAY_SIZE=$(( 117*2*3*1000000/8 )) # Use this for 2 socket runs
```

## Build with GNU compiler
```
# ggcompile001
module purge
module load gcc/13.3.0-gcc-11.4.1
module load openmpi/5.0.6-gcc-13.3.0
mpicc stream_mpi.c \
  -O3 -ffast-math -mcpu=neoverse-v2 -fno-builtin \
  -DSTREAM_ARRAY_SIZE=${STREAM_ARRAY_SIZE} -DNTIMES=${NTIMES} \
  -o stream_mpi.gcc


# gg001
mpirun -np 144 ./stream_mpi.gcc
[...]
Total Aggregate Array size = 87750000 (elements)
Total Aggregate Memory per array = 669.5 MiB (= 0.7 GiB).
Total Aggregate memory required = 2008.4 MiB (= 2.0 GiB).
Data is distributed across 144 MPI ranks
   Array size per MPI rank = 609375 (elements)
   Memory per array per MPI rank = 4.6 MiB (= 0.0 GiB).
   Total memory per MPI rank = 13.9 MiB (= 0.0 GiB).
[...]
```

## Build with NVIDIA compiler
```
# ggcompile001
module purge
module load nvhpc/24.11-gcc-13.3.0
module load openmpi/5.0.6-nvhpc-24.11
mpicc stream_mpi.c \
  -O3 -mcpu=neoverse-v2 -fno-builtin \
  -DSTREAM_ARRAY_SIZE=${STREAM_ARRAY_SIZE} -DNTIMES=${NTIMES} \
  -o stream_mpi.nvc
  

# gg001
mpirun -np 144 ./stream_mpi.nvc
[...]
Total Aggregate Array size = 87750000 (elements)
Total Aggregate Memory per array = 669.5 MiB (= 0.7 GiB).
Total Aggregate memory required = 2008.4 MiB (= 2.0 GiB).
Data is distributed across 144 MPI ranks
   Array size per MPI rank = 609375 (elements)
   Memory per array per MPI rank = 4.6 MiB (= 0.0 GiB).
   Total memory per MPI rank = 13.9 MiB (= 0.0 GiB).
[...]
```
