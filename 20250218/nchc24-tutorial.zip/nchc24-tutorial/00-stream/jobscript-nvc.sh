#!/bin/bash

#SBATCH --job-name=stream_nvc
#SBATCH --partition=gg
#SBATCH --ntasks=144
#SBATCH --cpus-per-task=1
#SBATCH --exclusive
#SBATCH --output=stream_nvc-%j.out

source /global/exafs/groups/gh/bootstrap-env-hipeac.sh
module purge
module load nvhpc/24.11-gcc-13.3.0
module load openmpi/5.0.6-nvhpc-24.11
module list

#STREAM_ARRAY_SIZE=$(( 117*1*3*1000000/8 )) # Use this for 1 socket runs
STREAM_ARRAY_SIZE=$(( 117*2*3*1000000/8 )) # Use this for 2 socket runs

NTIMES=100

mpicc stream_mpi.c \
  -O3 -mcpu=neoverse-v2 -fno-builtin \
  -DSTREAM_ARRAY_SIZE=${STREAM_ARRAY_SIZE} -DNTIMES=${NTIMES} \
  -o stream_mpi.nvc

mpirun -np 144 stream_mpi.nvc
