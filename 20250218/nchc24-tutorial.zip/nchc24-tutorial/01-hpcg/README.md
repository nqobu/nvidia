# HPCG

This guide covers compiling and running a vanilla version of HPCG.
NVIDIA also provides optimized versions of HPCG and other common HPC benchmarks through the [NGC catalog](https://catalog.ngc.nvidia.com/orgs/nvidia/containers/hpc-benchmarks).

```
# ggcompile001
# Download source code
git clone https://github.com/hpcg-benchmark/hpcg.git
cd hpcg

# Build with GNU compiler
mkdir build-gcc13.3.0-openmpi5.0.6
cd build-gcc13.3.0-openmpi5.0.6

module purge
module load gcc/13.3.0-gcc-11.4.1
module load openmpi/5.0.6-gcc-13.3.0

../configure MPI_GCC_OMP
make -j


# gg001
# Run simple test
cd bin
mpirun -np 144 ./xhpcg --nx=104 --rt=0
```
