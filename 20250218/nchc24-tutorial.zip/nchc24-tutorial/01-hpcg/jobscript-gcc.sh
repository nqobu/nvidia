#!/bin/bash

#SBATCH --job-name=hpcg_gcc
#SBATCH --partition=gg
#SBATCH --ntasks=144
#SBATCH --cpus-per-task=1
#SBATCH --exclusive
#SBATCH --output=hpcg_gcc-%j.out

source /global/exafs/groups/gh/bootstrap-env-hipeac.sh
module purge
module load gcc/13.3.0-gcc-11.4.1
module load openmpi/5.0.6-gcc-13.3.0
module list

mpirun -np 144 ./xhpcg --nx=104 --rt=300
