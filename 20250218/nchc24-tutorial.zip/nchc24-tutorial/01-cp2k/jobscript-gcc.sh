#!/bin/bash

#SBATCH --job-name=cp2k_gcc
#SBATCH --partition=gg
#SBATCH --ntasks=144
#SBATCH --cpus-per-task=1
#SBATCH --exclusive
#SBATCH --output=cp2k_gcc-%j.out

source /global/exafs/groups/gh/bootstrap-env-hipeac.sh
module purge
module load gcc/13.3.0-gcc-11.4.1-6ze
module load openmpi/5.0.6-gcc-13.3.0-t2h
module load nvpl/24.7-gcc-13.3.0-rdb
module list

# Medium input (~3min)
mpirun -np 144 ../../exe/Linux-thea-gcc11.4.1-nvpl24.7/cp2k.psmp -in H2O-256.inp

# Big input (>5min)
#mpirun -np 144 ../../exe/Linux-thea-gcc11.4.1-nvpl24.7/cp2k.psmp -in H2O-512.inp
