# CP2K
```
# Download source code
git clone -b support/v2025.1 --recursive https://github.com/cp2k/cp2k.git cp2k

# Load software modules (GNU+nvpl+fftw build)
# More info:
#   * https://docs.nvidia.com/nvpl/_static/blas/programming_model/building_and_linking.html
#   * https://docs.nvidia.com/nvpl/_static/lapack/programming_model/building_and_linking.html
module purge
module load gcc/13.3.0-gcc-11.4.1
module load openmpi/5.0.6-gcc-13.3.0
module load nvpl/24.7-gcc-13.3.0
module load fftw/3.3.10-gcc-13.3.0

# Build using configuration file found in this repository!
cd cp2k
cp <path_to_repo>/01-cp2k/Linux-thea-gcc11.4.1-nvpl24.7.psmp arch/.

make -j ARCH=Linux-thea-gcc11.4.1-nvpl24.7 VERSION=psmp
# It takes around 3min

# Run small H2O input
cd benchmarks/QS

mpirun -np 16 ../../exe/Linux-thea-gcc11.4.1-nvpl24.7/cp2k.psmp -in H2O-32.inp
# It takes around 30s...

mpirun -np 144 ../../exe/Linux-thea-gcc11.4.1-nvpl24.7/cp2k.psmp -in H2O-128.inp
# It takes around 30s...

mpirun -np 16 ../../exe/Linux-thea-gcc11.4.1-nvpl24.7/cp2k.psmp -in H2O-128.inp
# It takes around 3min...
```