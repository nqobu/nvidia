# Bootcamp Problems

A collection of some fast running examples with Jupyter notebooks for explanation
