import modulus
from modulus.hydra import to_absolute_path, to_yaml, instantiate_arch
from modulus.hydra.config import ModulusConfig
from modulus.key import Key

from modulus.discrete.constraints.constraint import SupervisedGridConstraint
from modulus.discrete.validator.validator import GridValidator
from modulus.discrete.dataset.datafile import HDF5DataFile

# Keeping these in continuous right now until future updates
from modulus.continuous.solvers.solver import Solver
from modulus.continuous.domain.domain import Domain

from modulus.tensorboard_utils.plotter import GridValidatorPlotter
from modulus.distributed.manager import DistributedManager

from utilities import download_FNO_dataset, load_FNO_dataset


@modulus.main(config_path="conf", config_name="config_FNO")
def run(cfg: ModulusConfig) -> None:

    if DistributedManager().distributed:
        print("Multi-GPU currently not supported for this example. Exiting.")
        return

    # load training/ test data
    input_keys = [Key("coeff", scale=(7.48360e00, 4.49996e00))]
    output_keys = [Key("sol", scale=(5.74634e-03, 3.88433e-03))]

    download_FNO_dataset("Darcy_241", outdir="datasets/")
    train_path = to_absolute_path(
        "datasets/Darcy_241/piececonst_r241_N1024_smooth1.hdf5"
    )
    invar_train = {"coeff": HDF5DataFile(train_path, "coeff")}  # lazy file loader
    outvar_train = {"sol": HDF5DataFile(train_path, "sol")}  # lazy file loader

    invar_test, outvar_test = load_FNO_dataset(
        "datasets/Darcy_241/piececonst_r241_N1024_smooth2.hdf5",
        [k.name for k in input_keys],
        [k.name for k in output_keys],
        n_examples=100,
    )

    # print out training/ test data shapes
    for d in (invar_test, outvar_test):
        for k in d:
            print(f"{k}: {d[k].shape}")

    # make list of nodes to unroll graph on
    model = instantiate_arch(
        input_keys=input_keys,
        output_keys=output_keys,
        cfg=cfg.arch.fno,
    )
    nodes = model.make_nodes(name="FNO", jit=cfg.jit)

    # make domain
    domain = Domain()

    # add constraints to domain
    supervised = SupervisedGridConstraint(
        nodes=nodes,
        invar=invar_train,
        outvar=outvar_train,
        batch_size=cfg.batch_size.grid,
        cell_volumes=None,
        lambda_weighting=None,
        lazy_loading=True,  # Turn on lazy loading
        num_workers=4,  # number of parallel data loaders
    )
    domain.add_constraint(supervised, "supervised")

    # add validator
    val = GridValidator(
        invar_test,
        outvar_test,
        nodes,
        batch_size=cfg.batch_size.validation,
        plotter=GridValidatorPlotter(n_examples=5),
    )
    domain.add_validator(val, "test")

    # make solver
    slv = Solver(cfg, domain)

    # start solver
    slv.solve()


if __name__ == "__main__":
    run()
